import { useState } from 'react'
import { login, register } from '../api'
import Orb from './Orb'

function fieldErrors(error) {
  const errors = error?.response?.data?.errors
  if (errors) return Object.fromEntries(Object.entries(errors).map(([k, v]) => [k, v[0]]))
  if (!error?.response) return { form: "Serverga ulanib bo'lmadi. Backend ishlayotganini tekshiring." }
  if (error.response.status === 429) return { form: "Juda ko'p urinish. Bir daqiqadan so'ng qayta urinib ko'ring." }
  return { form: error.response.data?.message ?? "Xatolik yuz berdi. Qayta urinib ko'ring." }
}

export default function AuthScreen({ onAuthenticated }) {
  const [mode, setMode] = useState('login')
  const [form, setForm] = useState({ name: '', username: '', password: '' })
  const [errors, setErrors] = useState({})
  const [busy, setBusy] = useState(false)
  const isRegister = mode === 'register'

  const update = (key) => (e) => {
    setForm((f) => ({ ...f, [key]: e.target.value }))
    setErrors((er) => ({ ...er, [key]: undefined, form: undefined }))
  }

  async function submit(e) {
    e.preventDefault()
    setBusy(true)
    setErrors({})
    try {
      const user = isRegister
        ? await register(form.name.trim(), form.username.trim(), form.password)
        : await login(form.username.trim(), form.password)
      onAuthenticated(user)
    } catch (err) {
      setErrors(fieldErrors(err))
      setBusy(false)
    }
  }

  return (
    <main className="auth">
      <header className="hero">
        <Orb phase="idle" size="130px" />
        <h1>
          {isRegister ? (
            <>
              English bilan <span className="gradient-text">tanishing</span>
            </>
          ) : (
            <>
              Qaytganingizdan <span className="gradient-text">xursandmiz</span>
            </>
          )}
        </h1>
        <p>
          {isRegister
            ? "Akkaunt oching — English siz bilan gaplashgan sari sizni yaxshiroq bilib, darslarni sizga moslab boradi."
            : 'Akkauntingizga kiring, English sizni kutyapti.'}
        </p>
      </header>

      <form className="glass auth-form" onSubmit={submit} noValidate>
        <div className="segmented two" role="tablist">
          <button
            type="button"
            role="tab"
            aria-selected={!isRegister}
            className={!isRegister ? 'active' : ''}
            onClick={() => {
              setMode('login')
              setErrors({})
            }}
          >
            <strong>Kirish</strong>
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={isRegister}
            className={isRegister ? 'active' : ''}
            onClick={() => {
              setMode('register')
              setErrors({})
            }}
          >
            <strong>Ro'yxatdan o'tish</strong>
          </button>
        </div>

        {isRegister && (
          <label className="field">
            <span>Ismingiz</span>
            <input
              className={`text-input ${errors.name ? 'invalid' : ''}`}
              value={form.name}
              onChange={update('name')}
              placeholder="Masalan: Aziz"
              autoComplete="given-name"
              maxLength={60}
              required
            />
            {errors.name && <small className="field-error">{errors.name}</small>}
          </label>
        )}

        <label className="field">
          <span>Login</span>
          <input
            className={`text-input ${errors.username ? 'invalid' : ''}`}
            value={form.username}
            onChange={update('username')}
            placeholder="masalan: aziz_2000"
            autoComplete="username"
            autoCapitalize="none"
            spellCheck={false}
            maxLength={30}
            required
          />
          {errors.username && <small className="field-error">{errors.username}</small>}
        </label>

        <label className="field">
          <span>Parol</span>
          <input
            type="password"
            className={`text-input ${errors.password ? 'invalid' : ''}`}
            value={form.password}
            onChange={update('password')}
            placeholder={isRegister ? 'Kamida 6 ta belgi' : '••••••'}
            autoComplete={isRegister ? 'new-password' : 'current-password'}
            required
          />
          {errors.password && <small className="field-error">{errors.password}</small>}
        </label>

        {errors.form && <div className="form-error">{errors.form}</div>}

        <button
          type="submit"
          className="btn-primary large"
          disabled={busy || !form.username || !form.password || (isRegister && !form.name.trim())}
        >
          {busy ? 'Kutib turing...' : isRegister ? 'Akkaunt ochish' : 'Kirish'}
        </button>
      </form>
    </main>
  )
}
