import { typeLabel } from '../mistakeTypes'

function escapeRegExp(text) {
  return text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

// Underlines the wrong fragments inside the learner's own sentence.
export function HighlightedText({ text, corrections }) {
  const fragments = [...new Set((corrections ?? []).map((c) => c.original).filter(Boolean))]
  if (!fragments.length) return text

  fragments.sort((a, b) => b.length - a.length)
  const pattern = new RegExp(`(${fragments.map(escapeRegExp).join('|')})`, 'g')

  return text.split(pattern).map((part, i) =>
    fragments.includes(part) ? (
      <mark key={i} className="mistake">
        {part}
      </mark>
    ) : (
      part
    ),
  )
}

export function CorrectionItem({ correction }) {
  return (
    <li className="correction">
      <div className="correction-diff">
        <span className="wrong">{correction.original}</span>
        <svg className="arrow" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
          <path d="M5 12h14M13 6l6 6-6 6" />
        </svg>
        <span className="right">{correction.corrected}</span>
        {correction.type && <span className="tag">{typeLabel(correction.type)}</span>}
      </div>
      {correction.explanation && <p className="correction-why">{correction.explanation}</p>}
    </li>
  )
}
