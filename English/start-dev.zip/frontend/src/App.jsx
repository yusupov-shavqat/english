import { useCallback, useEffect, useState } from 'react'
import { fetchMe, finishChat, handleUnauthorized, hasToken, logout, setToken } from './api'
import AuthScreen from './components/AuthScreen'
import ChatScreen from './components/ChatScreen'
import Orb from './components/Orb'
import SetupScreen from './components/SetupScreen'
import SummaryScreen from './components/SummaryScreen'

const SETTINGS_KEY = 'tutor-settings'
const DEFAULT_SETTINGS = { duration: 5, level: 'intermediate', topic: '', explanationLanguage: 'uz' }

function loadSettings() {
  try {
    return { ...DEFAULT_SETTINGS, ...JSON.parse(localStorage.getItem(SETTINGS_KEY)) }
  } catch {
    return DEFAULT_SETTINGS
  }
}

function saveSettings(settings) {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings))
  } catch {
    // Storage may be blocked; settings just won't be remembered.
  }
}

export default function App() {
  const [user, setUser] = useState(null)
  const [booting, setBooting] = useState(hasToken)
  const [screen, setScreen] = useState('setup')
  const [settings, setSettings] = useState(loadSettings)
  const [result, setResult] = useState(null)
  // Remounts the chat so every session starts fresh.
  const [sessionKey, setSessionKey] = useState(0)

  const signOut = useCallback(() => {
    setToken(null)
    setUser(null)
    setScreen('setup')
  }, [])

  useEffect(() => {
    handleUnauthorized(signOut)
    if (!hasToken()) return
    fetchMe()
      .then(setUser)
      .catch(() => signOut())
      .finally(() => setBooting(false))
  }, [signOut])

  const refreshUser = () => fetchMe().then(setUser).catch(() => {})

  // Saves the session and lets English update what she remembers about the learner.
  const closeSession = (conversationId, secondsUsed) => {
    if (!conversationId) return Promise.resolve(null)
    return finishChat(conversationId, secondsUsed).finally(refreshUser)
  }

  const startSession = (next) => {
    setSettings(next)
    saveSettings(next)
    setSessionKey((k) => k + 1)
    setScreen('chat')
  }

  if (booting) {
    return (
      <main className="boot">
        <Orb phase="connecting" size="120px" />
      </main>
    )
  }

  if (!user) {
    return <AuthScreen onAuthenticated={setUser} />
  }

  if (screen === 'chat') {
    return (
      <ChatScreen
        key={sessionKey}
        settings={settings}
        onExit={({ conversationId, secondsUsed }) => {
          closeSession(conversationId, secondsUsed).catch(() => {})
          setScreen('setup')
        }}
        onFinish={(r) => {
          setResult({ ...r, memory: 'saving' })
          setScreen('summary')
          closeSession(r.conversationId, r.secondsUsed)
            .then((profile) => setResult((cur) => ({ ...cur, memory: 'saved', profile })))
            .catch(() => setResult((cur) => ({ ...cur, memory: 'failed' })))
        }}
      />
    )
  }

  if (screen === 'summary') {
    return (
      <SummaryScreen
        result={result}
        onRestart={() => startSession(settings)}
        onNewSettings={() => setScreen('setup')}
      />
    )
  }

  return (
    <SetupScreen
      user={user}
      initial={settings}
      onStart={startSession}
      onLogout={() => logout().finally(signOut)}
    />
  )
}
